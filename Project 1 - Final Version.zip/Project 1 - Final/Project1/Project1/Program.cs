﻿// Carli Theron
// Taryn Mackenna
// Jacobus Theo Petrus Snyman
// Nathan Van Der Westhuizen
// Willem Kruger
// Thato Motlhasedi
// Karl Schmutz

using System;
using System.Collections;

namespace Project1
{
    class Program
    {
        static void Main(string[] args)
        {
            var arrlistEmployees = new ArrayList();
            char ans = ' ';
            Program n = new Program();

            do
            {
                Console.WriteLine("Select an option below:");
                Console.WriteLine("-----------------------");
                Console.WriteLine("0 -- Capture details of new applicants");
                Console.WriteLine("1 -- Display qualified applicants");
                Console.WriteLine("2 -- Display statistics of all applicants");
                Console.WriteLine("3 -- Exit application");
                Console.WriteLine();
                int menuOption = Int32.Parse(Console.ReadLine());

                switch ((menu)menuOption)
                {
                    case menu.Capture:
                        captureApplicantDetails(arrlistEmployees);
                        break;
                    case menu.display:
                        display();
                        break;
                    case menu.stats:
                        showStats();
                        break;
                    case menu.exit:
                        Environment.Exit(2);
                        break;
                    default:
                        Console.WriteLine();
                        Console.WriteLine("Error: You have entered a menu value that does not exist!");
                        Console.WriteLine();
                        break;
                }
            } 
            while (ans != 'Q');
        }

        static int qualifiedCount = 0;
        static int notQualifiedCount = 0;
        static string sline = "";

        enum menu
        {
            Capture,
            display,
            stats,
            exit
        }

        static ArrayList captureApplicantDetails(ArrayList arrlistEmployees)
        {
            char ans = ' ';
            int count = 0;

            do
            {
                count++;
                Console.WriteLine();
                Console.WriteLine("---------------------");
                Console.Write("Insert applicant's name: "); //0
                string applicantName = (Console.ReadLine());

            redo:
                Console.WriteLine();
                Console.Write("Is the applicant employed? Insert ( Y / N ): "); //1
                char applicantEmploymentStatus = char.Parse(Console.ReadLine().ToUpper());

                if (applicantEmploymentStatus != 'Y' && applicantEmploymentStatus != 'N')
                {
                    Console.WriteLine("----------------------------");
                    Console.WriteLine("Error: Only insert ( Y / N )");
                    Console.WriteLine("----------------------------");
                    goto redo;
                }
                int applicantYearsEmployed = 0;
                if (applicantEmploymentStatus == 'Y')
                {
            redoYears:
                    Console.WriteLine();
                    Console.Write("Applicant's active years in current employment: "); //2
                    applicantYearsEmployed = Int32.Parse(Console.ReadLine());

                    if (applicantYearsEmployed < 0)
                    {
                        Console.WriteLine("----------------------------------------------");
                        Console.WriteLine("Error: Cannot enter a value smaller than ( 0 )");
                        Console.WriteLine("----------------------------------------------");
                        goto redoYears;
                    }
                }
                int applicantResidenceYears = 0;
            redoResidenceYears:
                Console.WriteLine();
                Console.Write("Applicant's total years at current residence: "); //2
                applicantResidenceYears = Int32.Parse(Console.ReadLine());

                if (applicantResidenceYears < 0)
                {
                    Console.WriteLine("----------------------------------------------");
                    Console.WriteLine("Error: Cannot enter a value smaller than ( 0 )");
                    Console.WriteLine("----------------------------------------------");
                    goto redoResidenceYears;
                }

                Console.WriteLine();
                Console.Write("Enter applicant's monthly salary: R"); //4
                double applicantSalary = double.Parse(Console.ReadLine());

                Console.WriteLine();
                Console.Write("Enter applicant's amount of non-mortgage debt: R"); // 5
                double applicantDebt = double.Parse(Console.ReadLine());

            redoChildren:
                Console.WriteLine();
                Console.Write("Enter applicant's amount of children: "); // 6
                int applicantTotalChildren = Int32.Parse(Console.ReadLine());

                if (applicantTotalChildren < 0)
                {
                    Console.WriteLine("----------------------------------------------");
                    Console.WriteLine("Error: Cannot enter a value smaller than ( 0 )");
                    Console.WriteLine("----------------------------------------------");
                    goto redoChildren;
                }
                Console.WriteLine();
                Console.Write("Do you want to add another applicant? Insert ( Y / N ): ");
                ans = char.Parse(Console.ReadLine().ToUpper());

                bool qualified = checkQualified(applicantYearsEmployed, applicantResidenceYears, applicantSalary, applicantDebt, applicantTotalChildren);
                if (qualified)
                {
                    arrlistEmployees.Add(applicantName);
                    arrlistEmployees.Add(applicantEmploymentStatus);
                    arrlistEmployees.Add(applicantYearsEmployed);
                    arrlistEmployees.Add(applicantResidenceYears);
                    arrlistEmployees.Add(applicantDebt);
                    arrlistEmployees.Add(applicantTotalChildren);
                    qualifiedCount++;
                    Console.WriteLine("----------------------------");
                    Console.WriteLine("Client qualifies for credit!");
                    Console.WriteLine("----------------------------");
                    Console.WriteLine();

                    formatting(applicantName, applicantEmploymentStatus, applicantYearsEmployed, applicantResidenceYears, applicantSalary, applicantDebt, applicantTotalChildren);

                    string sline = "";
                    sline += "\n Name: " + applicantName.ToString();
                    sline += "\n Employed: " + applicantEmploymentStatus;
                    sline += "\n Years employed: " + applicantYearsEmployed;
                    sline += "\n Residence period : " + applicantResidenceYears;
                    sline += "\n Montly salary: R##,## " + applicantSalary;
                    sline += "\n Non-mortgage debt: R##,##" + applicantDebt;
                    sline += "\n Total Children: " + applicantTotalChildren;
                    Console.WriteLine();
                }
                else
                {
                    notQualifiedCount++;
                    Console.WriteLine("-----------------------------------");
                    Console.WriteLine("Client does not qualify for credit!");
                    Console.WriteLine();
                }

            } while (ans != 'N');
            return arrlistEmployees;
        }

        static bool checkQualified(int y, int ry, double sal, double mor, int chil)
        {
            bool check = false;
            if (y >= 1 && ry >= 2 && mor < (sal * 2) && chil <= 6)
            {
                check = true;

            }
            return check;
        }

        static void showStats()
        {
            Console.WriteLine("Total people who are - \nQaulified: {0} \nNot Qualified: {0}", qualifiedCount, notQualifiedCount);
        }

        static string formatting(string name, char employed, int years, int ryears, double salary, double mortage,  int children)
        {   
            sline += "\n Name: " + name.ToString();
            sline += "\n Employed: " + employed;
            sline += "\n Years employed: " + years;
            sline += "\n Residence period: " + ryears;
            sline += "\n Montly salary: " + salary;
            sline += "\n Non-mortgage debt:" + mortage;
            sline += "\n Total children: " + children;
            Console.WriteLine();

            return sline;
        }

        static void display()
        {
            Console.WriteLine(sline);
        }
    }
}
